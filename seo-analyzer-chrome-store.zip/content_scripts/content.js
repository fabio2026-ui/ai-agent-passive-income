// SEO Analyzer Pro - Content Script

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'analyze') {
    const data = performAnalysis(request.isPro);
    sendResponse(data);
  }
  return true;
});

function performAnalysis(isPro) {
  // Analysis logic moved to popup.js executeScript
  return {};
}