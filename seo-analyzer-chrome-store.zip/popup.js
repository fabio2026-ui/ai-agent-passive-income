// SEO Analyzer Pro - Popup Script

const FREE_PLAN = 'free';
const PRO_PLAN = 'pro';

let currentPlan = FREE_PLAN;
let analysisData = null;

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  await loadPlanStatus();
  setupEventListeners();
  updateUI();
});

async function loadPlanStatus() {
  const result = await chrome.storage.local.get(['seoPlan', 'seoAnalysisCount']);
  currentPlan = result.seoPlan || FREE_PLAN;
  window.analysisCount = result.seoAnalysisCount || 0;
}

function setupEventListeners() {
  document.getElementById('analyzeBtn').addEventListener('click', analyzePage);
  document.getElementById('upgradeBtn').addEventListener('click', () => {
    window.open('https://ai-empire.com/seo-analyzer/upgrade', '_blank');
  });
  document.getElementById('settingsBtn').addEventListener('click', openSettings);
  document.getElementById('helpBtn').addEventListener('click', openHelp);
}

function updateUI() {
  const badge = document.getElementById('planBadge');
  const proLocked = document.getElementById('proLocked');
  const proContent = document.getElementById('proContent');
  
  if (currentPlan === PRO_PLAN) {
    badge.textContent = 'PRO';
    badge.classList.add('pro');
    proLocked.classList.add('hidden');
    proContent.classList.remove('hidden');
  } else {
    badge.textContent = 'FREE';
    badge.classList.remove('pro');
    proLocked.classList.remove('hidden');
    proContent.classList.add('hidden');
  }
}

async function analyzePage() {
  const loading = document.getElementById('loading');
  const results = document.getElementById('results');
  
  loading.classList.remove('hidden');
  results.classList.add('hidden');
  
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab) {
      throw new Error('无法获取当前页面');
    }
    
    // Inject content script if needed
    const results_data = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractSEOData,
      args: [currentPlan === PRO_PLAN]
    });
    
    analysisData = results_data[0].result;
    displayResults(analysisData);
    
    // Increment analysis count for free plan
    if (currentPlan === FREE_PLAN) {
      window.analysisCount++;
      await chrome.storage.local.set({ seoAnalysisCount: window.analysisCount });
    }
    
  } catch (error) {
    console.error('Analysis error:', error);
    showError('分析失败: ' + error.message);
  } finally {
    loading.classList.add('hidden');
    results.classList.remove('hidden');
  }
}

function extractSEOData(isPro) {
  const data = {
    url: window.location.href,
    title: document.title,
    description: '',
    charset: document.characterSet,
    viewport: '',
    canonical: '',
    score: 0,
    issues: []
  };
  
  // Meta description
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc) {
    data.description = metaDesc.getAttribute('content') || '';
  }
  
  // Viewport
  const viewportMeta = document.querySelector('meta[name="viewport"]');
  if (viewportMeta) {
    data.viewport = viewportMeta.getAttribute('content') || '';
  }
  
  // Canonical
  const canonical = document.querySelector('link[rel="canonical"]');
  if (canonical) {
    data.canonical = canonical.getAttribute('href') || '';
  }
  
  // Calculate score (free features)
  let score = 100;
  
  // Title checks
  if (!data.title) {
    score -= 20;
    data.issues.push({ type: 'error', title: '缺少标题', desc: '页面没有设置title标签' });
  } else if (data.title.length < 30) {
    score -= 10;
    data.issues.push({ type: 'warning', title: '标题过短', desc: '标题应至少30个字符' });
  } else if (data.title.length > 60) {
    score -= 5;
    data.issues.push({ type: 'warning', title: '标题过长', desc: '标题建议控制在60个字符以内' });
  }
  
  // Description checks
  if (!data.description) {
    score -= 20;
    data.issues.push({ type: 'error', title: '缺少描述', desc: '页面没有设置meta description' });
  } else if (data.description.length < 120) {
    score -= 10;
    data.issues.push({ type: 'warning', title: '描述过短', desc: '描述应至少120个字符' });
  } else if (data.description.length > 160) {
    score -= 5;
    data.issues.push({ type: 'warning', title: '描述过长', desc: '描述建议控制在160个字符以内' });
  }
  
  // Viewport check
  if (!data.viewport) {
    score -= 10;
    data.issues.push({ type: 'warning', title: '缺少视口设置', desc: '建议添加viewport meta标签' });
  }
  
  // Pro features
  if (isPro) {
    data.pro = {
      headings: extractHeadings(),
      images: analyzeImages(),
      openGraph: extractOpenGraph(),
      twitterCard: extractTwitterCard(),
      links: analyzeLinks(),
      schema: extractSchemaOrg()
    };
    
    // Additional pro scoring
    const h1Count = data.pro.headings.h1.length;
    if (h1Count === 0) {
      score -= 15;
      data.issues.push({ type: 'error', title: '缺少H1标签', desc: '页面应该有一个H1标题' });
    } else if (h1Count > 1) {
      score -= 10;
      data.issues.push({ type: 'warning', title: '多个H1标签', desc: '页面建议只有一个H1标题' });
    }
    
    const imagesWithoutAlt = data.pro.images.withoutAlt.length;
    if (imagesWithoutAlt > 0) {
      score -= Math.min(15, imagesWithoutAlt * 2);
      data.issues.push({ 
        type: 'warning', 
        title: '图片缺少Alt标签', 
        desc: `${imagesWithoutAlt}张图片没有alt属性` 
      });
    }
  }
  
  data.score = Math.max(0, score);
  data.goodPractices = [
    { title: 'HTTPS安全', status: data.url.startsWith('https://') },
    { title: '字符编码', status: !!data.charset },
    { title: '规范URL', status: !!data.canonical }
  ];
  
  return data;
}

function extractHeadings() {
  const headings = { h1: [], h2: [], h3: [], h4: [], h5: [], h6: [] };
  for (let i = 1; i <= 6; i++) {
    const elements = document.querySelectorAll(`h${i}`);
    headings[`h${i}`] = Array.from(elements).map(h => ({
      text: h.textContent.trim(),
      length: h.textContent.trim().length
    }));
  }
  return headings;
}

function analyzeImages() {
  const images = document.querySelectorAll('img');
  const result = {
    total: images.length,
    withAlt: 0,
    withoutAlt: [],
    list: []
  };
  
  images.forEach((img, index) => {
    const alt = img.getAttribute('alt');
    const src = img.src || img.getAttribute('data-src') || '';
    const hasAlt = alt !== null && alt !== '';
    
    if (hasAlt) {
      result.withAlt++;
    } else {
      result.withoutAlt.push({ src: src.substring(0, 50), index });
    }
    
    if (index < 10) {
      result.list.push({
        src: src.substring(0, 100),
        alt: alt || '(无alt)',
        hasAlt
      });
    }
  });
  
  return result;
}

function extractOpenGraph() {
  const og = {};
  const metaTags = document.querySelectorAll('meta[property^="og:"]');
  metaTags.forEach(tag => {
    const property = tag.getAttribute('property');
    const content = tag.getAttribute('content');
    if (property && content) {
      og[property.replace('og:', '')] = content;
    }
  });
  return og;
}

function extractTwitterCard() {
  const twitter = {};
  const metaTags = document.querySelectorAll('meta[name^="twitter:"]');
  metaTags.forEach(tag => {
    const name = tag.getAttribute('name');
    const content = tag.getAttribute('content');
    if (name && content) {
      twitter[name.replace('twitter:', '')] = content;
    }
  });
  return twitter;
}

function analyzeLinks() {
  const links = document.querySelectorAll('a[href]');
  const hostname = window.location.hostname;
  const result = {
    total: links.length,
    internal: 0,
    external: 0,
    nofollow: 0
  };
  
  links.forEach(link => {
    const href = link.getAttribute('href');
    const rel = link.getAttribute('rel') || '';
    
    if (href.startsWith('http')) {
      if (href.includes(hostname)) {
        result.internal++;
      } else {
        result.external++;
      }
    } else if (!href.startsWith('#') && !href.startsWith('javascript:')) {
      result.internal++;
    }
    
    if (rel.includes('nofollow')) {
      result.nofollow++;
    }
  });
  
  return result;
}

function extractSchemaOrg() {
  const schemas = [];
  const scripts = document.querySelectorAll('script[type="application/ld+json"]');
  scripts.forEach(script => {
    try {
      const data = JSON.parse(script.textContent);
      schemas.push(data);
    } catch (e) {
      // Invalid JSON
    }
  });
  return schemas;
}

function displayResults(data) {
  // Basic info
  document.getElementById('pageTitle').textContent = data.title || '(未设置)';
  document.getElementById('titleLength').textContent = `长度: ${data.title.length} 字符`;
  document.getElementById('titleLength').className = 'info-meta ' + getLengthStatus(data.title.length, 30, 60);
  
  document.getElementById('pageDescription').textContent = data.description || '(未设置)';
  document.getElementById('descLength').textContent = `长度: ${data.description.length} 字符`;
  document.getElementById('descLength').className = 'info-meta ' + getLengthStatus(data.description.length, 120, 160);
  
  document.getElementById('pageUrl').textContent = data.url;
  
  // Score
  const score = data.score;
  document.getElementById('scoreValue').textContent = score;
  const scoreCircle = document.getElementById('scoreCircle');
  const scoreStatus = document.getElementById('scoreStatus');
  
  if (score >= 80) {
    scoreCircle.style.borderColor = '#22c55e';
    scoreStatus.textContent = 'SEO表现优秀';
    scoreStatus.style.background = 'rgba(34, 197, 94, 0.2)';
  } else if (score >= 60) {
    scoreCircle.style.borderColor = '#f59e0b';
    scoreStatus.textContent = 'SEO表现良好';
    scoreStatus.style.background = 'rgba(245, 158, 11, 0.2)';
  } else {
    scoreCircle.style.borderColor = '#ef4444';
    scoreStatus.textContent = '需要优化';
    scoreStatus.style.background = 'rgba(239, 68, 68, 0.2)';
  }
  
  // Pro content
  if (currentPlan === PRO_PLAN && data.pro) {
    displayProContent(data.pro);
  }
  
  // Recommendations
  displayRecommendations(data);
}

function getLengthStatus(length, min, max) {
  if (length === 0) return 'danger';
  if (length < min) return 'warning';
  if (length > max) return 'warning';
  return 'good';
}

function displayProContent(pro) {
  // Headings
  document.getElementById('h1Count').textContent = pro.headings.h1.length;
  const h1List = document.getElementById('h1List');
  if (pro.headings.h1.length > 0) {
    h1List.innerHTML = pro.headings.h1.map(h => 
      `&lt;span class="tag"&gt;${escapeHtml(h.text.substring(0, 50))}&lt;/span&gt;`
    ).join('');
  } else {
    h1List.innerHTML = '&lt;span class="tag error"&gt;未找到H1标签&lt;/span&gt;';
  }
  
  // Heading tree
  const headingTree = document.getElementById('headingTree');
  let treeHtml = '';
  for (let i = 2; i <= 6; i++) {
    const hs = pro.headings[`h${i}`];
    if (hs.length > 0) {
      treeHtml += `&lt;div class="tree-level"&gt;H${i}: ${hs.length}个&lt;/div&gt;`;
    }
  }
  headingTree.innerHTML = treeHtml || '无副标题';
  
  // Images
  document.getElementById('totalImages').textContent = pro.images.total;
  document.getElementById('imagesWithAlt').textContent = pro.images.withAlt;
  document.getElementById('imagesWithoutAlt').textContent = pro.images.withoutAlt.length;
  
  const imageList = document.getElementById('imageList');
  imageList.innerHTML = pro.images.list.map(img => `
    <div class="image-item ${img.hasAlt ? '' : 'missing-alt'}">
      <span>${img.hasAlt ? '✅' : '⚠️'}</span>
      <span>${escapeHtml(img.alt.substring(0, 30))}</span>
    </div>
  `).join('');
  
  // Open Graph
  const ogList = document.getElementById('ogList');
  const ogKeys = Object.keys(pro.openGraph);
  if (ogKeys.length > 0) {
    ogList.innerHTML = ogKeys.map(key => 
      `&lt;div class="tag"&gt;${key}: ${escapeHtml(pro.openGraph[key].substring(0, 30))}&lt;/div&gt;`
    ).join('');
  } else {
    ogList.innerHTML = '&lt;span class="tag error"&gt;未设置Open Graph&lt;/span&gt;';
  }
  
  // Links
  document.getElementById('internalLinks').textContent = pro.links.internal;
  document.getElementById('externalLinks').textContent = pro.links.external;
}

function displayRecommendations(data) {
  const container = document.getElementById('recommendations');
  let html = '';
  
  // Issues
  data.issues.forEach(issue => {
    html += `
      <div class="recommendation-item ${issue.type}">
        <span class="rec-icon">${issue.type === 'error' ? '❌' : '⚠️'}&lt;/span>
        <div class="rec-text">
          <div class="rec-title">${issue.title}&lt;/div>
          <div class="rec-desc">${issue.desc}&lt;/div>
        </div>
      </div>
    `;
  });
  
  // Good practices
  data.goodPractices.forEach(practice => {
    if (practice.status) {
      html += `
        <div class="recommendation-item good">
          <span class="rec-icon">✅&lt;/span>
          <div class="rec-text">
            <div class="rec-title">${practice.title}&lt;/div>
          </div>
        </div>
      `;
    }
  });
  
  container.innerHTML = html || '<p class="placeholder">未发现明显问题</p>';
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function showError(message) {
  const container = document.getElementById('recommendations');
  container.innerHTML = `
    <div class="recommendation-item error">
      <span class="rec-icon">❌&lt;/span>
      <div class="rec-text">
        <div class="rec-title">分析失败&lt;/div>
        <div class="rec-desc">${message}&lt;/div>
      </div>
    </div>
  `;
}

function openSettings() {
  // Open settings page
  chrome.runtime.openOptionsPage?.() || alert('设置功能开发中...');
}

function openHelp() {
  window.open('https://ai-empire.com/seo-analyzer/help', '_blank');
}