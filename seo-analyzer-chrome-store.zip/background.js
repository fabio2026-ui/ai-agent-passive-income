// SEO Analyzer Pro - Background Service Worker

chrome.runtime.onInstalled.addListener(() => {
  console.log('SEO Analyzer Pro installed');
  
  // Initialize storage
  chrome.storage.local.set({
    seoPlan: 'free',
    seoAnalysisCount: 0
  });
});

// Handle context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'analyzeSEO',
    title: '使用SEO Analyzer分析此页面',
    contexts: ['page']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'analyzeSEO') {
    chrome.action.openPopup();
  }
});